package com.techknowpaarai.a24techv1;

public class SearchResponseNew {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
