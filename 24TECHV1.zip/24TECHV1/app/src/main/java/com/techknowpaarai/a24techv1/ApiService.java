package com.techknowpaarai.a24techv1;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiService {
    @POST("login")
    Call<LoginResponse> loginUser(@Query("username") String value1 , @Query("password") String value);

    @GET("search")
    Call<List<SearchResponseNew>> searchProfile(@Query("city") String value1 );
}