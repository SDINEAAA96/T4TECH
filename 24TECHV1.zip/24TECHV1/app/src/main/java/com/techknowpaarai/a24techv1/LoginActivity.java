package com.techknowpaarai.a24techv1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                // Create the login request
                LoginRequest request = new LoginRequest(username,password);

                // Make the API call using Retrofit
                ApiService apiService = RetrofitClient.getApiService();
                Call<LoginResponse> call = apiService.loginUser(request.getUsername(),request.getPassword());


                call.enqueue(new Callback<LoginResponse>() {
                    @Override
                    public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                        if (response.isSuccessful()) {
                            LoginResponse loginResponse = response.body();
                            if (loginResponse != null) {
                                String token = loginResponse.getUsername();
                               // Toast.makeText(LoginActivity.this, "successful"+loginResponse.getUsername(), Toast.LENGTH_SHORT).show();
                                navigateToSearchScreen();
                            }
                        } else {
                            int statuscode = response.code();
                            Toast.makeText(LoginActivity.this, "message"+statuscode, Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponse> call, Throwable t) {
                     //   Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
    private void navigateToSearchScreen() {
        Intent intent = new Intent(this, SearchActivity.class);
        startActivity(intent);
       // finish(); // Optional: finish the LoginActivity so that the user cannot go back to it with the back button
    }
}
