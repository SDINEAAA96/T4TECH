package com.techknowpaarai.a24techv1;

public class SearchProfile {
    private String city;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
