package com.techknowpaarai.a24techv1;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchResultsActivity extends AppCompatActivity {

    RecyclerView searchResult;
    SearchResultsAdapter searchResultsAdapter;
    List<SearchResponseNew> searchResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchresults);
        searchResult= findViewById(R.id.profilesearchresult);
        searchResult.setLayoutManager(new LinearLayoutManager(this));
        String searchQuery = getIntent().getStringExtra("searchQuery");
        searchResults = new ArrayList<>();
        searchResultsAdapter = new SearchResultsAdapter(SearchResultsActivity.this.searchResults);
        searchResult.setAdapter(searchResultsAdapter);
        performSearch(searchQuery);
       // searchResultsAdapter.notifyDataSetChanged();

    }

    private void performSearch(String searchQuery) {
        // Use Retrofit to perform the API call and get the search results
        // Replace ApiService and ApiClient with your actual Retrofit implementation
        SearchProfile searchRequest = new SearchProfile();
        searchRequest.setCity(searchQuery);
        ApiService apiService = RetrofitClientSearch.getApiService();
        Call<List<SearchResponseNew>> call = apiService.searchProfile(searchQuery);
        call.enqueue(new Callback<List<SearchResponseNew>>() {
            @Override
            public void onResponse(Call<List<SearchResponseNew>> call, Response<List<SearchResponseNew>> response) {
                if (response.isSuccessful()) {
                     searchResults = response.body();
                    searchResultsAdapter.setSearchResults(searchResults);
                         //  Toast.makeText(SearchResultsActivity.this, call.request().url().toString(), Toast.LENGTH_SHORT).show();

                 //  Toast.makeText(SearchResultsActivity.this, "successful Search Result"+searchResults.size(), Toast.LENGTH_SHORT).show();
                    searchResultsAdapter.notifyDataSetChanged();
                     //  updateSearchResults(searchResults);
                }
            }

            @Override
            public void onFailure(Call<List<SearchResponseNew>> call, Throwable t) {
                // Handle API call failure
            }
        });
    }


    }


