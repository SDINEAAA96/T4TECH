package com.techknowpaarai.a24techv1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchActivity extends AppCompatActivity {

    private EditText searchEditText;
    private Button searchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city = searchEditText.getText().toString();

                // Create the login request
                SearchProfile searchRequest = new SearchProfile();
                searchRequest.setCity(city);

                // Make the API call using Retrofit
                ApiService apiService = RetrofitClientSearch.getApiService();
              //  Toast.makeText(SearchActivity.this, searchRequest.getCity(), Toast.LENGTH_SHORT).show();

                Call<List<SearchResponseNew>> call = apiService.searchProfile(searchRequest.getCity());

                String urlvalue = call.request().url().toString();
             // Toast.makeText(SearchActivity.this, urlvalue, Toast.LENGTH_SHORT).show();

                call.enqueue(new Callback<List<SearchResponseNew>>() {
                    @Override
                    public void onResponse(Call<List<SearchResponseNew>> call, Response<List<SearchResponseNew>> response) {
                   //       Toast.makeText(SearchActivity.this, urlvalue, Toast.LENGTH_SHORT).show();

                        if (response.isSuccessful()) {
                            List<SearchResponseNew> searchResponse = response.body();

                            if (searchResponse != null) {
                                //String token = searchResponse.getName();
                                // Toast.makeText(SearchActivity.this, "successful", Toast.LENGTH_SHORT).show();
                                performSearch(city);
                            }
                        } else {
                            int statuscode = response.code();
                            Toast.makeText(SearchActivity.this, "message"+statuscode, Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<SearchResponseNew>> call, Throwable t) {
                           Toast.makeText(SearchActivity.this, "Login failed"+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });
    }

    private void performSearch(String searchQuery) {
        // Here, you can implement the logic to search for data based on the query.
        // For example, you could use an API or query a local database.
        // For this example, we will start a new activity to display the search results.

        Intent intent = new Intent(this, SearchResultsActivity.class);
        intent.putExtra("searchQuery", searchQuery);
        startActivity(intent);
    }
}
