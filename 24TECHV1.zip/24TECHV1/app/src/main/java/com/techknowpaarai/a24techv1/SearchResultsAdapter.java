package com.techknowpaarai.a24techv1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SearchResultsAdapter extends RecyclerView.Adapter<SearchResultsAdapter.SearchResultViewHolder> {
    private List<SearchResponseNew> searchResults;

    public SearchResultsAdapter(List<SearchResponseNew> searchResults) {
        this.searchResults = searchResults;
    }

    @NonNull
    @Override
    public SearchResultViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_resultitem, parent, false);
        return new SearchResultViewHolder(itemView);
    }

    public void setSearchResults(List<SearchResponseNew> searchResults) {
        this.searchResults = searchResults;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull SearchResultViewHolder holder, int position) {
        SearchResponseNew searchResultItem = searchResults.get(position);
        holder.tvSearchResult.setText(searchResultItem.getName());
    }

    @Override
    public int getItemCount() {
        return searchResults.size();
    }

    public  class SearchResultViewHolder extends RecyclerView.ViewHolder {
        TextView tvSearchResult;

        public SearchResultViewHolder(View itemView) {
            super(itemView);
            tvSearchResult = itemView.findViewById(R.id.textViewTitle);
        }

    }
}

